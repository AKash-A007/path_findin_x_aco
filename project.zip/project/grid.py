DIRECTIONS = [(-1, 0), (1, 0), (0, -1), (0, 1)]

def is_valid_move(x, y, grid, visited):
    """Check if a move is valid."""
    return (
        0 <= x < len(grid) and
        0 <= y < len(grid[0]) and
        not visited[x][y] and
        grid[x][y] != "D"
    )

def find_survivors(grid):
    return [(x, y) for x, row in enumerate(grid) for y, cell in enumerate(row) if cell == "S"]

def find_recharge_stations(grid):
    return [(x, y) for x, row in enumerate(grid) for y, cell in enumerate(row) if cell == "R"]
