# import tkinter as tk

# def visualize_path(grid, path, survivors):
#     """Visualize the robot's path using tkinter and print the path in the terminal step by step."""
#     ROWS, COLS = len(grid), len(grid[0])
#     CELL_SIZE = 50

#     # Create the tkinter window
#     root = tk.Tk()
#     root.title("Rescue Robot Path Visualization")

#     canvas = tk.Canvas(root, width=COLS * CELL_SIZE, height=ROWS * CELL_SIZE)
#     canvas.pack()

#     # Draw the initial grid (only once)
#     def draw_grid():
#         for row in range(ROWS):
#             for col in range(COLS):
#                 x1, y1 = col * CELL_SIZE, row * CELL_SIZE
#                 x2, y2 = x1 + CELL_SIZE, y1 + CELL_SIZE

#                 # Set colors based on cell type
#                 color = "white"
#                 if grid[row][col] == "D":
#                     color = "red"  # Danger
#                 elif grid[row][col] == "S":
#                     color = "blue"  # Survivor
#                 elif grid[row][col] == "R":
#                     color = "green"  # Recharge station

#                 canvas.create_rectangle(x1, y1, x2, y2, fill=color, outline="black")

#     # Function to update robot's position and animate
#     def update_robot(step=0, robot=None):
#         if step >= len(path):
#             return  # End of path, no more steps to animate

#         position = path[step]
#         row, col = position
#         x1, y1 = col * CELL_SIZE + CELL_SIZE // 4, row * CELL_SIZE + CELL_SIZE // 4
#         x2, y2 = x1 + CELL_SIZE // 2, y1 + CELL_SIZE // 2
#         robot = canvas.create_line(x1,y1,x2,y2,fill="black")


#         # Print the current position of the robot in the terminal
#         print(f"Step {step + 1}: Robot moved to position {position}")
        
#         # Mark the robot's path in transparent grey (light grey)
#         canvas.create_rectangle(col * CELL_SIZE, row * CELL_SIZE, 
#                                 col * CELL_SIZE + CELL_SIZE, row * CELL_SIZE + CELL_SIZE, 
#                                 fill="#D3D3D3", outline="black")

#         # Draw the robot at the new position
#         robot = canvas.create_line(x1,y1,x2,y2,fill="black")
#         robot = canvas.create_oval(x1, y1, x2, y2, fill="yellow", outline="black")

#         # Highlight rescued survivors
#         if position in survivors:
#             canvas.create_text(
#                 col * CELL_SIZE + CELL_SIZE // 2,
#                 row * CELL_SIZE + CELL_SIZE // 2,
#                 text="S",
#                 fill="black",
#                 font=("Helvetica", 16, "bold")
#             )

#         # Schedule the next step after a short delay (500 ms)
#         root.after(500, update_robot, step + 1, robot)

#     # Draw the initial grid once at the beginning
#     draw_grid()

#     # Initialize the robot (empty value initially)
#     robot = None

#     # Start the robot movement from step 0
#     update_robot()

#     # Keep the window open
#     root.mainloop()

# if __name__ == "__main__":
#     # Import the path and survivors (you can get this from your `robot` object or a saved path)
#     from cave_matrix import generate_cave
#     from robot import RescueRobot
#     import pprint

#     # Initialize the cave grid and robot
#     cave_grid = generate_cave()
#     robot = RescueRobot(cave_grid)
#     robot.start_rescue()

#     # Call the visualization function
#     visualize_path(cave_grid, robot.path_taken, robot.survivors_rescued)
import tkinter as tk
import time
def create_grid(canvas, grid, cell_size=30):
    """Create the grid based on the grid layout."""
    rows = len(grid)
    cols = len(grid[0])
    for i in range(rows):
        for j in range(cols):
            x1 = j * cell_size
            y1 = i * cell_size
            x2 = (j + 1) * cell_size
            y2 = (i + 1) * cell_size
            color = 'white'

            if grid[i][j] == "D":  # Obstacle
                color = 'black'
            elif grid[i][j] == "S":  # Survivor
                color = 'green'
            elif grid[i][j] == "R":  # Recharge station
                color = 'blue'

            canvas.create_rectangle(x1, y1, x2, y2, fill=color, outline='black')

def visualize_path(grid, total_path, survivors=None, cell_size=30, speed=500):
    """Visualize the robot's movement through the grid."""
    root = tk.Tk()
    root.title("Robot Path Visualization")

    rows = len(grid)
    cols = len(grid[0])

    canvas = tk.Canvas(root, width=cols * cell_size, height=rows * cell_size)
    canvas.pack()

    create_grid(canvas, grid, cell_size)

    # Start position (first coordinate in the path)
    start = total_path[0]
    robot = canvas.create_oval(
        start[1] * cell_size + 5, start[0] * cell_size + 5,
        start[1] * cell_size + cell_size - 5, start[0] * cell_size + cell_size - 5,
        fill='red'
    )

    # Highlight survivors
    if survivors:
        for survivor in survivors:
            x1 = survivor[1] * cell_size + 5
            y1 = survivor[0] * cell_size + 5
            x2 = survivor[1] * cell_size + cell_size - 5
            y2 = survivor[0] * cell_size + cell_size - 5
            canvas.create_oval(x1, y1, x2, y2, fill="green", outline="black")
            canvas.create_text(survivor[1] * cell_size + cell_size // 2,
                               survivor[0] * cell_size + cell_size // 2,
                               text="S", fill="white", font=("Helvetica", 16, "bold"))

    def move_robot(i=0):
        """Move the robot along the path with recursion."""
        if i < len(total_path):
            current_pos = total_path[i]
            x1 = current_pos[1] * cell_size + 5
            y1 = current_pos[0] * cell_size + 5
            x2 = current_pos[1] * cell_size + cell_size - 5
            y2 = current_pos[0] * cell_size + cell_size - 5

            # Update robot position on the canvas
            canvas.coords(robot, x1, y1, x2, y2)

            # Call the move_robot function recursively after a delay
            root.after(speed, move_robot, i + 1)

    # Start the animation
    move_robot()

    root.mainloop()


# Example grid with obstacles (D), survivors (S), and recharge stations (R)

if __name__ == "__main__":
    # Import the path and survivors (you can get this from your `robot` object or a saved path)
    from cave_matrix import generate_cave
    from robot import RescueRobot

    # Initialize the cave grid and robot
    cave_grid = generate_cave()
    robot = RescueRobot(cave_grid)
    robot.start_rescue()

    # Call the visualization function
    visualize_path(cave_grid, robot.path_taken, robot.survivors_rescued)
# import tkinter as tk
# import time
# from cave_matrix import generate_cave
# from robot import RescueRobot

# def create_grid(canvas, grid, cell_size=70):
#     """Creates the grid visualization on the canvas."""
#     rows = len(grid)
#     cols = len(grid[0])
#     for row in range(rows):
#         for col in range(cols):
#             x1 = col * cell_size
#             y1 = row * cell_size
#             x2 = (col + 1) * cell_size
#             y2 = (row + 1) * cell_size
#             color = "white"
#             if grid[row][col] == "D":  # Obstacle
#                 color = "black"
#             elif grid[row][col] == "S":  # Survivor
#                 color = "green"
#             elif grid[row][col] == "R":  # Recharge station
#                 color = "blue"
#             canvas.create_rectangle(x1, y1, x2, y2, fill=color, outline="black")

# def visualize_path(grid, path, survivors=None, cell_size=70, speed=200):
#     """Visualizes the robot's path on the grid."""
#     root = tk.Tk()
#     root.title("Robot Path Visualization")
#     rows = len(grid)
#     cols = len(grid[0])
#     canvas = tk.Canvas(root, width=cols * cell_size, height=rows * cell_size)
#     canvas.pack()
#     create_grid(canvas, grid, cell_size)

#     # Create robot representation
#     robot = canvas.create_oval(0, 0, cell_size, cell_size, fill='red', outline='black')

#     # Highlight survivors
#     survivor_positions = set(survivors) if survivors else set()
#     survivor_cells = []  # To store survivor cells' coordinates
#     if survivors:
#         for survivor in survivors:
#             x1 = survivor[1] * cell_size + 5
#             y1 = survivor[0] * cell_size + 5
#             x2 = survivor[1] * cell_size + cell_size - 5
#             y2 = survivor[0] * cell_size + cell_size - 5
#             canvas.create_oval(x1, y1, x2, y2, fill="green", outline="black")
#             canvas.create_text(survivor[1] * cell_size + cell_size // 2,
#                                survivor[0] * cell_size + cell_size // 2,
#                                text="S", fill="white", font=("Helvetica", 16, "bold"))
#             survivor_cells.append(survivor)

#     visited_cells = set()

#     def move_robot(i=0):
#         if i < len(path):
#             current_pos = path[i]
#             x1 = current_pos[1] * cell_size
#             y1 = current_pos[0] * cell_size
#             x2 = (current_pos[1] + 1) * cell_size
#             y2 = (current_pos[0] + 1) * cell_size

#             # Highlight the previously visited cells in light green
#             for cell in visited_cells:
#                 if cell not in path[:i]:  # Don't color cells that are part of the current path
#                     cx1 = cell[1] * cell_size
#                     cy1 = cell[0] * cell_size
#                     cx2 = (cell[1] + 1) * cell_size
#                     cy2 = (cell[0] + 1) * cell_size
#                     canvas.create_rectangle(cx1, cy1, cx2, cy2, fill="white", outline="")

#             # Highlight the current path cell in light green
#             canvas.create_rectangle(x1, y1, x2, y2, fill="light green", outline="green")

#             # Update robot position on the canvas
#             canvas.coords(robot, x1 + 5, y1 + 5, x2 - 5, y2 - 5)

#             # Mark the current cell as visited
#             visited_cells.add(current_pos)

#             # Schedule the next movement
#             root.after(speed, move_robot, i + 1)

#     # Color path between survivors as robot moves
#     def color_survivor_path(i):
#         if i < len(survivors) - 1:
#             start = survivors[i]
#             end = survivors[i + 1]
#             # Find the path between two survivors (assuming `find_path`)
#             path_between_survivors = find_path(grid, start, end)
            
#             # Move through the path and color it blue
#             for j in range(len(path_between_survivors) - 1):
#                 current_pos = path_between_survivors[j]
#                 x1 = current_pos[1] * cell_size
#                 y1 = current_pos[0] * cell_size
#                 x2 = (current_pos[1] + 1) * cell_size
#                 y2 = (current_pos[0] + 1) * cell_size
#                 # Color this cell blue
#                 canvas.create_rectangle(x1, y1, x2, y2, fill="green", outline="blue")
            
#             # Schedule next survivor path coloring
#             root.after(speed, color_survivor_path, i + 1)

#     # Start the survivor path coloring
#     if survivors:
#         color_survivor_path(0)

#     # Start the robot movement
#     move_robot()
#     root.mainloop()

# def find_path(grid, start, end):
#     """Finds the path from one survivor to another (using BFS for simplicity)."""
#     from collections import deque

#     rows = len(grid)
#     cols = len(grid[0])
#     directions = [(0, 1), (1, 0), (0, -1), (-1, 0)]  # Right, Down, Left, Up
#     queue = deque([(start, [start])])  # (current_position, path_so_far)
#     visited = set()

#     while queue:
#         (current_row, current_col), path = queue.popleft()

#         if (current_row, current_col) == end:
#             return path  # Return the path from start to end

#         visited.add((current_row, current_col))

#         for dr, dc in directions:
#             new_row, new_col = current_row + dr, current_col + dc
#             if 0 <= new_row < rows and 0 <= new_col < cols and (new_row, new_col) not in visited:
#                 if grid[new_row][new_col] != "D":  # Don't traverse obstacles
#                     queue.append(((new_row, new_col), path + [(new_row, new_col)]))

#     return []  # Return an empty path if no path is found

# # Example usage (assuming you have cave_matrix and robot modules)
# if __name__ == "__main__":
#     cave_grid = generate_cave()  # Assuming generate_cave generates a cave grid
#     robot = RescueRobot(cave_grid)  # Assuming RescueRobot handles the rescue logic
#     robot.start_rescue()  # Start the robot's rescue operation
#     m = robot.path_taken  # Get the path the robot takes
#     print(m)  # Print the path
#     visualize_path(cave_grid, robot.path_taken, robot.survivors_rescued)  # Visualize the path and survivors
